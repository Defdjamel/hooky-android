/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.heyhooky.sdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.heyhooky.sdk";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_SDK = "1.0.0";
}
